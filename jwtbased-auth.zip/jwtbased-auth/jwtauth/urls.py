from django.urls import include, path
from .views import registration

urlpatterns = [
    path('register/', registration, name='register')
]
