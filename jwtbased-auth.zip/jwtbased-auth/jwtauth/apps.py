from django.apps import AppConfig


class JwtauthConfig(AppConfig):
    name = 'jwtauth'
