from django.urls import path
from rest_framework.routers import SimpleRouter
from .views import UserServiceViewSet

router = SimpleRouter()
router.register('userService', UserServiceViewSet, basename="userService")
urlpatterns = router.urls
