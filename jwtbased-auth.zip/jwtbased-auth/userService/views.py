from django.shortcuts import render
from rest_framework import viewsets
from .models import UserService
from .serializers import UserServiceSerializer
from rest_framework import viewsets
from rest_framework import permissions
from .models import UserService
from .serializers import UserServiceSerializer
from rest_framework.exceptions import PermissionDenied

class UserServiceViewSet(viewsets.ModelViewSet):
    queryset = UserService.objects.all()
    serializer_class = UserServiceSerializer


class IsOwner(permissions.BasePermission):
    
    def has_object_permission(self, request, view, obj):
        return obj.owner == request.user


class UserServiceViewSet(viewsets.ModelViewSet):
    serializer_class = UserServiceSerializer
    permission_classes = (IsOwner,)
    
    def get_queryset(self):
        user = self.request.user
        if user.is_authenticated:
            return UserService.objects.filter(owner=user)
        raise PermissionDenied()
        
    def perform_create(self, serializer):
        serializer.save(owner=self.request.user)