from django.contrib import admin
from .models import UserService

# Register your models here.

admin.site.register(UserService)
